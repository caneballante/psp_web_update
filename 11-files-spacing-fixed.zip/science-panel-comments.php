<!DOCTYPE html>
<html lang="en"><!-- InstanceBegin template="/Templates/page-4-template.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- InstanceBeginEditable name="doctitle" -->
<title>Puget Sound Partnership - State of the Sound</title>
<!-- InstanceEndEditable -->
<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/custom.css" rel="stylesheet" type="text/css">
<link href="css/custom-erika.css" rel="stylesheet" type="text/css">


<!-- loads the wf-loading class right away to minimize FOUT -->
<script>document.documentElement.className += ' wf-loading';</script>
<!-- Font PRENTON TYPEKIT -->
<script src="https://use.typekit.net/srt5jze.js"></script>
<script>try{Typekit.load({ async: true });}catch(e){}</script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<!-- InstanceBeginEditable name="head" -->
<script>
/*this variable is used to set the proper nav to active. It should to the order the nav item is in the list*/
  	navSelected = 1;
</script>
<!-- InstanceEndEditable -->
<!-- InstanceParam name="OptionalRegion1" type="boolean" value="true" -->
<!-- InstanceParam name="OptionalRegion2" type="boolean" value="false" -->
<!-- InstanceParam name="OptionalRegion3" type="boolean" value="true" -->
<!-- InstanceParam name="OptionalRegion4" type="boolean" value="false" -->
<!-- InstanceParam name="OptionalRegion5" type="boolean" value="true" -->
<!-- InstanceParam name="OptionalRegion6" type="boolean" value="true" -->
<!-- InstanceParam name="OptionalRegion7" type="boolean" value="false" -->
</head>
<body>
<?php include 'includes/modal-inc.html';?>
<!-- START IMAGE HEADER --> 
 <!-- InstanceBeginEditable name="overviewphoto" -->
<header class="overview-page-image-style overview-page-image81">
	<div class="overview-quote pull-right">
		<h3></h3>
	</div>
</header>
<!-- InstanceEndEditable -->  
<div class="container page-content padding-50-bottom">
	<div class="row">
		<div class="col-md-3 padding-20-top"></div>
		<div class="col-md-7 padding-20-top"> <!-- InstanceBeginEditable name="6col_header" -->
			<h1>Science Panel comments</h1>
			<!-- InstanceEndEditable --></div>
		<div class="col-md-2 padding-20-top"></div>
	</div>
	
	<div class="row"> 
		<div class="col-md-3">
			<ul class="nav nav-stacked nav-pills nav-leftside-custom padding-left-0 margin-10-top margin-left-20">
			<!-- InstanceBeginEditable name="left_nav" -->
					<?php include 'includes/ln-sos.html';?>
				<!-- InstanceEndEditable --> 
			</ul>
		
		</div>
			
	
		<div class="col-md-7 padding-20-top content-column">
		<!-- InstanceBeginEditable name="6col_content" -->
			<p><a href="https://pspwa.box.com/s/b8dpakebc3cxapvx9u05mzg1ky411f8n" title="Science panel comments on implementing the Action Agenda and findings from the Monitoring Program (download)">Science panel comments on implementing the Action Agenda and findings from the Monitoring Program (download)</a> </p>
			<p>Science Panel comments address three key objectives:</p>
			<ul>
				<li>How the ecosystem is doing in the context of progress toward the 2020 goals. </li>
				<li>How the Partnership is doing in advancing the Action Agenda and tracking expenditures and accomplishments. </li>
				<li>How well recovery efforts are linked to ecosystem status.</li>
			</ul>
			<p>Overall, the Science Panel is encouraged by the following:</p>
			<ul>
				<li>The progress of Puget Sound ecosystem recovery in key areas. </li>
				<li>That more than 70 percent of the Near Term Actions are complete or moving forward. </li>
				<li>The progress s in linking ecosystem status to recovery efforts. </li>
			</ul>
			<p>However, many Vital Signs have no changed or are even deteriorating relative to the goals. Given these findings, the Science Panel notes additional actions are needed to maintain and increase the rate of recovery. </p>
			<p>The Science Panel also notes that future NTAs can be improved by matching their scale to the 2-year implementation period, and by ensuring that the number of NTAs does not expand beyond the region&rsquo;s capacity to fund and complete within the 2-year implementation window.</p>
			<p> Adaptive management, the process of continuous improvement based on new data and analysis, is the approach the Science Panel strongly endorses for the Partnership&rsquo;s adaptive management approach has been inconsistently applied, partly due to inadequate resources. As a key step in implementing adaptive management, the completion of Implementation Strategies for each target should be a high priority, while recognizing a phased approach to developing the strategies. The deployment of conceptual models that describe the mechanisms, cause and effect pathways, and actions by which recovery targets are to be met can aid the effectiveness of an adaptive management approach.</p>
			<p> It is worth noting that in many ways the Puget Sound region is leading the country in ecosystem recovery, especially in incorporating human wellbeing explicitly into the science and implementation of recovery actions. As we look beyond 2020, the region can expect to have a stronger scientific foundation for recovery and a rich set of information to chart the course for the next phase of restoring the Sound and building the ecosystem resilience to adapt to climate change. </p>
			<p>Near Term Actions in the 2012 and 2014 Action Agendas were expected to be implemented in a 2- to 3-year time frame. However, most of the 2012 Action Agenda NTAs were not completed in 2 years, and more than 25 percent made insufficient or no progress at all. </p>
			<!-- InstanceEndEditable -->
		</div>
	
		<div class="col-md-2 padding-20-top"> 
			<!-- InstanceBeginRepeat name="right_nav_repeat" --><!-- InstanceBeginRepeatEntry --> 
				<!-- InstanceBeginEditable name="right_nav_title" -->
			<div class="right-nav-title margin-0-top ">RELATED DOWNLOADS</div>
			<!-- InstanceEndEditable -->
					<ul class="nav-rightside-custom">
						<!-- InstanceBeginEditable name="right_nav_links" -->
				<li role="presentation"><a href="#">NTA Status Analysis</a></li>
				<li role="presentation"><a href="#">NTA Expenditure &amp; Funding Gaps Analysis</a></li>
				<li role="presentation"><a href="#">Action Agenda Funding Analysis</a></li>
				<li role="presentation"><a href="#">Linkages Report</a></li>
				<li role="presentation"> <a href="https://pspwa.box.com/s/fllcx5sjhbjuy9dh384n85answ6ntd5q">2015 State of the Sound: Report on the Puget Sound Vital Signs</a></li>
				<li role="presentation"> <a href="https://pspwa.box.com/s/rvf9d0s9eytsz07epppgn31ryatom2o5">2015 State of the Sound: Report to the Governor and the Legislature</a></li>
				<li role="presentation"> <a href="https://pspwa.box.com/s/qvbmbzgpj1bj5ccl9ir7vgkex3j8on9a">2015 State of the Sound: Report to the Community</a></li>
				<!-- InstanceEndEditable -->
					</ul>
			<!-- InstanceEndRepeatEntry --><!-- InstanceBeginRepeatEntry --> 
				<!-- InstanceBeginEditable name="right_nav_title" -->
					<div class="right-nav-title margin-20-top ">SEE ALSO</div>
				<!-- InstanceEndEditable -->
					<ul class="nav-rightside-custom">
						<!-- InstanceBeginEditable name="right_nav_links" -->
							<li role="presentation"> <a href="http://www.psp.wa.gov/vitalsigns">Puget Sound Vital Signs</a></li>
							<li role="presentation"> <a href="http://gismanager.rco.wa.gov/ntaportal" target="_blank">Action Agenda Report Card</a></li>
							<li role="presentation"> <a href="action_agenda_center.php">Action Agenda Center</a></li>
							<li role="presentation"> <a href="#">National Estuary Program Project Atlas</a></li>
							<li role="presentation"> <a href="http://gismanager.rco.wa.gov/ProjectAtlas" target="_blank">Puget Sound Project Atlas</a></li>
							<li role="presentation"> <a href="#">Strategic Initiative Funding Strategies</a></li>
						<!-- InstanceEndEditable -->
					</ul>
			<!-- InstanceEndRepeatEntry --><!-- InstanceEndRepeat -->
		</div>
	</div>
	<!--END OF ROW -->
</div>
<!--END OF CONTENT CONTAINER -->


<?php include 'includes/footer-inc.html';?>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.2.min.js"></script> 

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script> 
<!-- custom js --> 
<script src="js/custom.js"></script>
<!-- Google Tracking  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-69373425-1', 'auto');
  ga('send', 'pageview');

</script>

</body>
<!-- InstanceEnd --></html>
